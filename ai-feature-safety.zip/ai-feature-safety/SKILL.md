---
name: ai-feature-safety
description: Use when building or editing any AI feature — chat assistants, summaries, matching, recommendations, recaps, nudges — or any code that sends user content to a model or changes a model's system prompt. Protect PII, preserve safety guardrails, and bound cost. Not for non-AI features or pure UI work.
---

# AI feature safety

AI features routinely send sensitive personal content to models. They are where privacy and safety regressions slip in. Apply this to every AI-touching change.

## Protect user data

- **Redact or minimize PII before it leaves the app.** If the project has a redaction helper, route model-bound text through it; if not, strip or pseudonymize obvious identifiers (names, emails, phone numbers, IDs) that the feature doesn't actually need. Send the model the least personal data required to do the job.
- **Never log raw user content** (chat messages, reflections, documents, prompts/responses) to console or persistent logs. Log metadata only — user id, timestamps, token counts.
- Don't store model prompts/responses that contain personal data in a new table without a row-level-security policy. If you add such a table, the `supabase-rls-guard` rules apply.

## Preserve safety guardrails

- **Do not weaken or delete existing safety instructions in a system prompt.** If a prompt contains a crisis-response path (directing a user in distress toward professional help and clarifying the assistant's limits), keep an equivalent path intact when you edit it, and flag any change to it for review.
- Keep the assistant within its stated role. Don't broaden a narrow utility or support assistant into something that gives medical, legal, or mental-health directives.
- If you add a new surface where users can pour in personal struggles, add an appropriate crisis-redirect guardrail rather than leaving it open.

## Bound cost and behavior

- Keep **auth + a per-user rate limit** in front of every model call (see `edge-function-contract`). No new AI endpoint ships without it.
- Respect existing response and context limits. Don't send entire histories or whole documents when a scoped slice will do — it costs more and leaks more PII than needed.
- Reuse the model the feature already uses; don't silently swap models or providers as part of an unrelated change.

## Report back

- **AI change:** what the feature now sends to the model and why.
- **Privacy check:** what PII is redacted/excluded before the model sees it, and confirmation nothing raw is logged.
- **Safety check:** confirm crisis/role guardrails in the system prompt are intact (quote the line you kept), and that auth + rate limiting still gate the call.
