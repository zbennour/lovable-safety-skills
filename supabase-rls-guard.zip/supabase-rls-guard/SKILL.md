---
name: supabase-rls-guard
description: Use when adding or changing a Supabase table, migration, or row-level security policy — including new features that store user, customer, document, or any per-account data. Enforce row-level security and tenant isolation. Not for pure frontend/styling changes that touch no tables or policies.
---

# Supabase RLS guard

Most apps store sensitive per-user data, and every table is a potential cross-account leak. Apply this whenever you create or alter a table or policy.

## Non-negotiable rules

1. **Every new table gets RLS enabled in the same migration that creates it.**
   `ALTER TABLE public.<name> ENABLE ROW LEVEL SECURITY;` — never leave a table without it, even "internal" or "lookup" tables that hold user data.
2. **No table is left policy-less.** A table with RLS on but no policies denies all access and silently breaks features. Add the policies in the same migration.
3. **Default to owner-scoped access.** Rows are readable/writable only by the user they belong to:
   `USING (auth.uid() = user_id)` for select/update/delete, and `WITH CHECK (auth.uid() = user_id)` for insert/update.
4. **Check roles with a `SECURITY DEFINER` function, not a column on the user's own row.** Keep roles in a dedicated table (e.g. `user_roles`) and check them with a security-definer function such as `has_role(auth.uid(), 'admin')`. Never store a role on a `profiles` row and read it directly inside a policy — a user who can update their own profile can then escalate their own privileges. If a role-check function already exists in the project, reuse it; don't duplicate it.
5. **Never weaken a policy to "make it work."** If a query fails under RLS, fix the query or add a correctly-scoped policy. Do not add `USING (true)`, disable RLS, or fall back to the service-role key on the client to get past it.

## Hard boundaries

- **The service-role key never touches client code.** It belongs only in server-side edge functions. If a task seems to need elevated database access from the browser, that logic belongs in an edge function instead.
- Do not drop, rename, or repurpose an existing security function or policy without flagging it explicitly and explaining the blast radius first.
- Do not add a policy that lets one account read another's rows. Shared or cross-account visibility (e.g. a manager seeing a report, a viewer seeing an owner's data) must go through an explicit relationship check, not a blanket `true`.

## Before finishing, verify

- The table has RLS enabled **and** at least one policy per operation it needs (select/insert/update/delete).
- A user in account A cannot read or write account B's rows. State this as **"needs manual check with a second test account"** and ask for confirmation before shipping.
- Privileged actions go through a security-definer role check, not a client-trusted flag.

## Report back

- **Tables/policies changed:** name + the access rule in one line each.
- **Isolation check:** what stops cross-account access on the changed tables.
- **Manual verification needed:** the specific two-account test to run before launch.
