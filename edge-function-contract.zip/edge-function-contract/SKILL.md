---
name: edge-function-contract
description: Use when creating or editing a Supabase edge function — AI endpoints, data syncs, admin actions, scheduled jobs, webhooks, or seed/reset scripts. Enforce a consistent auth, rate-limit, CORS, and secret-handling contract. Not for frontend code or for SQL migrations.
---

# Edge function contract

Keep every edge function to the same security shape so protection stays uniform across the project. If the codebase already has functions, match their existing structure rather than inventing a new one.

## Every function must

1. **Handle CORS preflight first.**
   `if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });`
   Reuse a shared `corsHeaders` block and keep the allowed headers consistent across functions.
2. **Require an authenticated user.** Reject missing/malformed auth before doing anything:
   - Check the `authorization` header starts with `Bearer `; if not, return `401`.
   - Verify the token with a user-scoped client (e.g. `auth.getUser()` or `auth.getClaims()`). Pick one approach and use it consistently across the project.
   - Only treat the request as valid once a real user/claims object comes back.
3. **Validate input** before use. Confirm the expected body shape (types, required fields) and return `400` on bad input rather than throwing raw.
4. **Rate-limit per user** for anything that calls a model or does expensive work. Key the limit on the authenticated user id (not the IP), and return `429` when exceeded. A small `check_rate_limit` RPC backed by a table is a common pattern.
5. **Return typed JSON errors** with the right status (`401` / `400` / `429` / `500`) and `Content-Type: application/json`, never an unhandled throw that leaks a stack trace.

## Secret handling — hard rules

- Read secrets only from environment variables (`Deno.env.get(...)`): the service-role key, model/provider API keys, etc. **Never** hardcode them and **never** return them in a response or log them.
- The **service-role client is server-only** and used solely for privileged operations (rate-limit RPC, admin tasks). Never send the service-role key back to the client or expose it through a function's output.
- Use a **user-scoped** client (anon key + the caller's Authorization header) for anything that should respect RLS. Only reach for the service-role client when you deliberately need to bypass RLS, and keep that surface as small as possible.

## Avoid

- Don't disable JWT verification to make a function reachable. If a function must be public (e.g. a third-party webhook), say so explicitly and add your own signature/secret verification instead.
- Don't widen CORS beyond the project's norm without flagging it.
- Don't add a new model/provider call without keeping the existing auth + rate-limit gating in front of it.

## Report back

- **Function:** what it does and who is allowed to call it.
- **Contract check:** confirm OPTIONS handled, auth verified, input validated, rate-limit applied (or why not), secrets server-only.
- **Manual verification:** one call as an unauthenticated user (expect 401) and one over the rate limit (expect 429).
