---
name: safe-migrations
description: Use when writing or editing a Supabase SQL migration, or making any schema change — adding, altering, or dropping tables, columns, types, functions, or policies. Protect existing production data and keep migrations reversible. Not for application code, edge functions, or frontend changes.
---

# Safe migrations

A careless migration can drop a column of real user data or silently disable row-level security. Treat every schema change as touching live data.

## Before writing the migration

1. State in one sentence what the schema change is and which existing tables/columns it touches.
2. If the change is **destructive** (drops a table, column, type, function, constraint, or policy; renames something other code depends on; changes a column type in a lossy way), stop and call it out explicitly. Explain what data or behavior would be lost and ask for confirmation before generating it.
3. Prefer additive changes. Add a new nullable column rather than repurposing an existing one. Backfill in a separate, reviewable step rather than mixing data migration into the schema change.

## Rules for the migration body

- **Make it idempotent where possible.** Use `IF NOT EXISTS` / `IF EXISTS`, `CREATE OR REPLACE FUNCTION`, and guard policy creation so re-running doesn't error.
- **Any new table enables RLS in the same migration** and gets its policies there too — see the `supabase-rls-guard` skill. Never create a table and leave RLS for "later."
- **Never disable RLS** on an existing table to make something work. If a policy blocks a needed query, fix the policy, don't turn protection off.
- **Don't drop or replace a security function** (e.g. a role-check function) or an existing policy without flagging the blast radius first.
- Keep one logical change per migration so it can be reasoned about and rolled back.
- Set `NOT NULL` and defaults only when existing rows can satisfy them; otherwise add the column nullable, backfill, then tighten in a later migration.

## Hard boundaries

- No `DROP TABLE`, `DROP COLUMN`, `TRUNCATE`, or `DELETE FROM` against a table holding user data without explicit confirmation in this conversation.
- No destructive change bundled silently inside an otherwise additive migration.
- Don't edit a migration that has already been applied to production — write a new forward migration instead.

## Report back

- **Change:** what the migration does, additive vs destructive.
- **Data impact:** what existing data is affected and whether anything is lost.
- **Reversibility:** how this could be rolled back, or a note that it cannot be and why.
- **RLS check:** for any new table, confirm RLS + policies are included.
