---
name: keep-tests-green
description: Use when changing application logic, hooks, utilities, edge functions, or anything covered by existing tests — and before calling a task done. Keep the test suite meaningful and passing. Not for pure visual/styling tweaks with no logic and no associated tests.
---

# Keep tests green

Tests only protect a project if they stay honest and stay passing. AI agents often quietly break or bypass them. Apply this whenever you change covered logic.

## Rules

1. **When you change logic that has tests, update those tests in the same change.** If you alter a hook, util, mapper, or function that has a test alongside it, adjust the test to match the new intended behavior — don't leave it asserting the old behavior.
2. **When you add non-trivial logic, add a test for it.** Match the project's existing style and test runner (unit tests next to the file; end-to-end specs for user-facing flows). A new utility should ship with a unit test.
3. **Run the tests before declaring done.** Run the unit suite for changed areas, and the relevant end-to-end spec for changed user flows. Report the result.
4. **A failing test is a signal, not an obstacle.** If a test fails after your change, decide which is wrong — the code or the test — and fix the right one. Explain which you chose and why.

## Never do this

- **Do not delete, skip, comment out, or narrow a test (e.g. `.only` / `.skip`) just to make the suite pass.** Removing the assertion that catches a regression is worse than the regression.
- Do not weaken an assertion (e.g. changing an exact-value check to a truthy check) to dodge a failure without explaining why the looser assertion is actually correct.
- Do not introduce logic the existing tests can't reach and leave it entirely uncovered when a small test would cover it.
- Do not change test config or fixtures to suppress failures rather than fixing the underlying issue.

## Report back

- **Tests touched:** which specs you added or updated, and why.
- **Run result:** what you ran and whether it passed; paste the summary line.
- **Coverage gaps:** any changed logic you could not cover, with a one-line reason.
- If you could not run the suite in this environment, say so explicitly rather than implying it passed.
