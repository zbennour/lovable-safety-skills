---
name: surgical-edits
description: Use when I ask for a specific, scoped change to an existing app — fixing one bug, adjusting one component, editing copy, tweaking styling, or wiring a single feature. Make the smallest correct change and leave everything else untouched. Do NOT use for greenfield builds or when I explicitly ask for a broad refactor, redesign, or rewrite.
---

# Surgical edits

Your job is to make the **smallest change that fully satisfies the request** and nothing more. Most things that break an app during small edits come from touching code that was never part of the request. Treat every line outside the scope as off-limits unless changing it is genuinely required.

## Before you write any code

1. Restate the change in one sentence so we agree on scope.
2. Identify the **minimal set of files** the change actually requires. Name them.
3. If the request is ambiguous (more than one reasonable interpretation, or it could touch shared state/routing/auth/schema), ask one short clarifying question instead of guessing. Guessing wide is how apps break.

## What to change

- Edit only what the request needs. If a fix lives in one component, stay in that component.
- Match the existing patterns already in the file: same styling approach, same state library, same naming, same formatting. Do not introduce a new pattern for a small task.
- Preserve current behavior of everything you are not explicitly asked to change.

## What to avoid

- **No "while I'm here" improvements.** Do not refactor, rename, reformat, reorder, or "clean up" code that works and wasn't part of the request.
- **Do not regenerate files that already work.** Make a targeted edit; never rewrite a whole component to change a few lines.
- **Do not touch dependencies, config, environment variables, or the database schema** unless the request truly requires it — and if it does, say so explicitly and explain why before doing it.
- **Do not add a new library** to solve something the existing stack already handles.
- **Do not change shared utilities, layouts, providers, or routing** to fix a single-screen problem unless that is provably the only fix. Flag it if so.
- Never delete code you don't understand. If something looks unused, leave it and note it rather than removing it.

## Protect what already works

Before finishing, mentally trace anything that **shares state, props, routes, or data** with what you changed, and confirm you haven't altered its behavior. A change to a shared component, context, or hook can break screens far from the one in the request — check those too.

## Conserve effort and credits

- Prefer a precise diff over a full regeneration. Regenerating large files costs more and risks unrelated breakage.
- Don't re-run broad scaffolding or re-create infrastructure that already exists.
- If the request would require large or risky changes, pause and tell me the scope before spending the work, rather than charging ahead.

## Report back in this format

When done, give a short summary:

- **Changed:** each file touched, with a one-line reason for each.
- **Left untouched on purpose:** anything in scope-adjacent territory you deliberately did not modify (e.g. "did not alter the shared `AuthProvider`").
- **Verify manually:** the specific feature plus any adjacent feature that shares state or routes with it.

Do not describe the change as "done" until the original request is fully satisfied and you've confirmed nothing adjacent regressed.
